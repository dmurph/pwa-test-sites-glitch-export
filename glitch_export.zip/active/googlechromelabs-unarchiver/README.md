# Explosive Decompression Unarchiver

A Progressive Web App (PWA) that supports drag-and-drop file decompression
into a user's directory.

It also supports extension association on Chrome OS, so a user could click
on a `.tar.gz` file and have it open in this PWA.

The app is deployed at https://googlechromelabs-unarchiver.glitch.me/
for testing purposes.
