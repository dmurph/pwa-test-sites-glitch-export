

function recalcOutput() {
  
}