'use strict';
navigator.serviceWorker.register('serviceworker.js')
